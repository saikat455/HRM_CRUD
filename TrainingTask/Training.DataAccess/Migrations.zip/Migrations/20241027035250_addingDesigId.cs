﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Training.DataAccess.Migrations
{
    public partial class addingDesigId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "desigid",
                table: "employees",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_employees_desigid",
                table: "employees",
                column: "desigid");

            migrationBuilder.AddForeignKey(
                name: "FK_employees_designations_desigid",
                table: "employees",
                column: "desigid",
                principalTable: "designations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_employees_designations_desigid",
                table: "employees");

            migrationBuilder.DropIndex(
                name: "IX_employees_desigid",
                table: "employees");

            migrationBuilder.DropColumn(
                name: "desigid",
                table: "employees");
        }
    }
}