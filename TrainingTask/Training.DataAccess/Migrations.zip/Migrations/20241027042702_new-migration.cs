﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Training.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class newmigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_employees_departments_deptid",
                table: "employees");

            migrationBuilder.DropForeignKey(
                name: "fk_employees_designations_desigid",
                table: "employees");

            migrationBuilder.AddForeignKey(
                name: "fk_employees_departments_deptid",
                table: "employees",
                column: "deptid",
                principalTable: "departments",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_employees_designations_desigid",
                table: "employees",
                column: "desigid",
                principalTable: "designations",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_employees_departments_deptid",
                table: "employees");

            migrationBuilder.DropForeignKey(
                name: "fk_employees_designations_desigid",
                table: "employees");

            migrationBuilder.AddForeignKey(
                name: "fk_employees_departments_deptid",
                table: "employees",
                column: "deptid",
                principalTable: "departments",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "fk_employees_designations_desigid",
                table: "employees",
                column: "desigid",
                principalTable: "designations",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
